
from django import forms
from .models import Product,Message

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'price', 'image']
class MessageForm(forms.ModelForm):
    class Meta:
        model = Message
        fields = ['name', 'surname', 'email', 'message']

class ProductSearchForm(forms.Form):
      search_query = forms.CharField(label='Search', max_length=100)