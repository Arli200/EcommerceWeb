
from django.shortcuts import render, redirect, get_object_or_404
from django.core.exceptions import MultipleObjectsReturned, ObjectDoesNotExist

from .models import Product, CartItem
from .forms import ProductForm, MessageForm, ProductSearchForm


def home(request):
    products = Product.objects.all()

    return render(request, 'home.html', {'products': products})




def search(request):
    form = ProductSearchForm(request.GET)
    products = Product.objects.all()

    if form.is_valid():
        search_query = form.cleaned_data['search_query']
        if search_query:
            products = products.filter(name__icontains=search_query)

    return render(request, 'search.html', {'form': form, 'products': products})

def catalog(request):
    products = Product.objects.all()

    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('catalog')
    else:
        form = ProductForm()

    return render(request, 'catalog.html', {'form': form, 'products': products})




def erase_all(request):
        Product.objects.all().delete()
        return redirect('catalog')



def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)

    cart_items = CartItem.objects.filter( product=product)

    if cart_items.exists():
        cart_item = cart_items.first()
        cart_item.quantity += 1
        cart_item.save()
    else:
        CartItem.objects.create(product=product, quantity=1)


    return redirect('cart')

def cart(request):
    cart_items = CartItem.objects.all()
    return render(request, 'cart.html', {'cart_items': cart_items})