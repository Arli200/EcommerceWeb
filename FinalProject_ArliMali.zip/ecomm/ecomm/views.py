# ecommerce_app/views.py

from django.shortcuts import render, redirect
from . import views


